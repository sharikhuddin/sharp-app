export const brand = 'VisaBridge';
export const disclaimer = 'VisaBridge provides administrative and informational assistance only. We are not a government agency or law firm and do not guarantee visa approval.';
export const countries = ['Australia','Bangladesh','Canada','China','France','Germany','India','Italy','Japan','Netherlands','Nigeria','Pakistan','Saudi Arabia','Singapore','Spain','Turkey','United Arab Emirates','United Kingdom','United States'];
export const purposes = ['Tourist / Visitor','Business','Student','Family / Spouse','Work','Transit','Other'];
export const stages = ['Profile','Documents','Forms','Review','Appointment','Submitted','Decision'];
export const packages = [
  {id:'basic',name:'Basic',price:89,tagline:'Guided checklist + form assistance',features:['Visa preparation roadmap','Document checklist','Guided application questions','Progress dashboard']},
  {id:'plus',name:'Plus',price:189,tagline:'Everything in Basic + document review',features:['All Basic features','Document review by an agent','Application consistency check','Review comments and action items'],featured:true},
  {id:'concierge',name:'Concierge',price:349,tagline:'Dedicated assistance for complex trips',features:['All Plus features','Dedicated case manager','Appointment / interview preparation','Priority support messages']}
];
export const requirements = ['Passport bio page','Passport-style photograph','Travel itinerary','Proof of accommodation','Proof of funds','Travel insurance (if applicable)','Employment / study evidence (if applicable)'];
export const formQuestions = [
  {key:'surname',label:'Surname as shown in your passport',type:'text',section:'Personal details'},
  {key:'given_name',label:'Given name(s) as shown in your passport',type:'text',section:'Personal details'},
  {key:'date_of_birth',label:'Date of birth',type:'date',section:'Personal details'},
  {key:'occupation',label:'Current occupation',type:'text',section:'Current circumstances'},
  {key:'funding',label:'Who will cover your travel costs?',type:'text',section:'Trip details'},
  {key:'purpose_details',label:'Explain the purpose of travel',type:'textarea',section:'Trip details'},
  {key:'prior_refusal',label:'Have you had a visa refused before?',type:'select',choices:['Select','No','Yes','Prefer to discuss with an agent'],section:'Travel history'},
  {key:'prior_overstay',label:'Have you overstayed a visa before?',type:'select',choices:['Select','No','Yes','Prefer to discuss with an agent'],section:'Travel history'}
];
const today='2026-10-14';
export const demoApps = [
 {id:'demo-uk',owner_id:'demo-user',full_name:'Demo Traveler',nationality:'Pakistan',destination:'United Kingdom',purpose:'Tourist / Visitor',travel_from:'2027-02-10',travel_to:'2027-02-28',package_tier:'plus',stage:'Documents',status:'Awaiting documents',created_at:today,appointment_at:null,reference:'VB-DEMO-101'},
 {id:'demo-jp',owner_id:'demo-user',full_name:'Demo Traveler',nationality:'Pakistan',destination:'Japan',purpose:'Business',travel_from:'2027-04-02',travel_to:'2027-04-10',package_tier:'basic',stage:'Forms',status:'In progress',created_at:today,appointment_at:null,reference:'VB-DEMO-102'}
];
export const demoDocs=[{id:'demo-doc',owner_id:'demo-user',application_id:'demo-uk',document_type:'Passport bio page',file_name:'sample-passport-redacted.pdf',file_path:'demo-placeholder',status:'Needs Review',review_comment:'Demo note: sample needs clearer scan',uploaded_at:today}];
export const demoThreads=[{id:'demo-thread',owner_id:'demo-user',subject:'UK visitor visa questions',application_id:'demo-uk',status:'Open',created_at:today}];
export const demoMessages=[{id:'demo-msg1',thread_id:'demo-thread',owner_id:'demo-user',sender_role:'agent',body:'Welcome! This is sample conversation text. Our agent can review your checklist.',created_at:today}];
export const demoNotifications=[{id:'demo-notif',owner_id:'demo-user',title:'Demo passport review needed',body:'Your sample passport file needs another scan.',is_read:false,created_at:today}];
export const starterState=()=>({profile:{user_id:'demo-user',full_name:'Demo Traveler',nationality:'Pakistan',privacy_consent:true},applications:structuredClone(demoApps),documents:structuredClone(demoDocs),answers:[],threads:structuredClone(demoThreads),messages:structuredClone(demoMessages),notifications:structuredClone(demoNotifications),roles:[],events:[]});
