// Connect a dedicated Supabase project only after applying and auditing schema.sql.
// Never put a service-role/secret key here. Document intake requires an explicit review.
export const CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_PUBLISHABLE_KEY: '',
  ENABLE_DOCUMENT_UPLOADS: false,
};
